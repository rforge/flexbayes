# Gelman-Rubin diagnostic
gelman.diag.posterior  <- function(x, maxVars = 30, ...){
  if (nvar(x) > maxVars)
		x <- x[,1:maxVars]
	sims <- x$mcmc.list

	gelman.diag(sims, ...)
}

gelman.plot.posterior  <- function(x, maxVars = 6, ...){
  if (nvar(x) > maxVars)
		x <- x[,1:maxVars]
	sims <- x$mcmc.list

	gelman.plot(sims, ...)
}
