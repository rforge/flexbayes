
#include "S.h"
#include "rtErr.h"
#include "Vector.h"
#include "Matrix.h"

#include "BayesianPoissonIdLinkModel.h"
#include "BayesianHierarchicalGlmModel.h"
#include "MetropolisHastings.h"

//#include <stdio.h>

extern "C" {
/*
  Computes a Bayes Hierarchical Poisson Regression model:

  |  counts_ij ~ Poisson( e_ij lambda_ij )
  |
  |  lambda_ij ~ log-Normal( mu_ij, sigma2_j )
  |
  |  mu_ij = X_ij beta_j + M_ij gamma
  |
  |  sigma2_j ~ p( sigma2_j): could be common for all groups; or known, etc.
  |
  |  beta_j = Z_j alpha + beta_error :the random effects
  |
  |  gamma ~ flat prior == N( 0, +infty ) :the fixed effects
  |        or ~ Normal( gamma_0, Gamma_0 )
  |
  |  alpha ~ N( alpha_0, V_0 )
  |  beta_error ~ N( 0, tau2 V )
  |
  |  tau2 ~ p(tau2) or tau2V ~ InvWishart( nu, S )

    counts_ij: data response for i-th case on j-th group (counts)
    e_ij: data exposures (in units, e.g. hours)  
    X_j: data predictors for the random effects of the j-th group
    M_j: data predictors for the fixed effects
    Z_j: data predictors for the "population" or secodn level predictors

    j = 1, ..., J.

  lambda_ij are nuisance parameters, and are integrated out in the algorithm.

  p(tau2): could be InvChisq( nuTau0, tau02 )
                     non Informative: proper:   Uniform Shrinkage ( tau02 )
                                                Du Mouchel( tau02 )
                                      improper: proportional to tau2^(1 + b ), with b <= 0.
   
   same thing for p(sigma2_j).

   Robustness: distributions for gamma, beta and alpha can be made to follow Multivariate Student's t's.

   Computations are based on Gibbs and Metropolis-Hastings sampler drawings.
   burnInLength: number of initial Gibbs sampler iterations to discard.
   simulationsToPerform: number of Gibbs sampler drawings to keep as output.
   sampleFrequency: only iterations that are multiples of sampleFrequency are to be kept.


   OUTPUT
   ------
   The simulationsToPerform output simulations are returned in the array output_simulations.
   This should be an array of length 
     ( [J * p] + [r]  + q  + < 1 | q*q > + [J] + +[1] + [1] + < J | 1 > + n.obs ) * simulationsToPerform
   where 
   J: number of groups
   p: dimension of beta vector
   r: dimension of gamma vector
   q: dimension of alpha vector
   < 1 | q*q >: dimension of tau2 (either a random variable or a random matrix )
   J: augmented variables for t-distributed betas
   1: augmented variable for t-distributed gamma
   1: augmented variable for t-distributed alpha
   J: the sigma_j variables
   n.obs: number of observations lambda_ij's


   < .|. > denotes a choice.
   [.] denotes an optional argument.

   The above dimensions specification also denotes the order in which the simulations are returned:
         beta (by group), gamma, alpha, tau | tau2, 
               t_beta (by group), t_gamma, t_alpha, sigma_j (by group), lambda_ij <by group>

   Note: Simulations for tau (not tau2) are returned if tau2 is a scalar,
         otherwise, the matrices tau2 are returned.
         Simulations for sigma_j (not sigma2_j) are returned.

*/
void fitBayesianHPMIL( long * number_groups,
                     long * number_data,
                     long * dim_beta,
                     long * dim_gamma,
                     long * dim_alpha,
                     long * exposures_flag,

                     double * random_data,
                     double * fixed_data,
                     double * second_data,
                     double * data_counts,
                     double * data_exposures,

                     double * gammamean,
                     double * gammaCov,
                     double * gammaDF,
                     long * prior_gamma_type,

                     double * betamean,
                     double * betaCov,
                     double * betaDF,
                     long * prior_beta_type,

                     double * alphamean,
                     double * alphaCov,
                     double * alphaDF,
                     long * prior_alpha_type,

                     double * tauDF,
                     double * tauScale,
                     double * tauPower,
                     long * prior_tau_type,

                     double * sigmaDF,
                     double * sigmaScale,
                     double * sigmaPower,
                     long * common_sigma,
                     long * prior_sigma_type,

                     long * read_init_point,
                     double * betaInit,
                     double * gammaInit,
                     double * alphaInit,
                     double * tau2Init,

                     double * sigma2Init,

                     long * burnInLength,
                     long * simulationsToPerform,
                     long * sampleFrequency,

                     long * model_type,
                     long * print_statistics,
                     double * output_simulations,
                     double * mh_drawing_stats ) throw( rtErr ) 
{
  bool random_effects, fixed_effects, second_effects;
  int i, j, k, dim, number_obs, start_index, simulations_kept;

  CVector ** counts;
  CVector ** exposures;
  CMatrix ** random_predictors;
  CMatrix ** fixed_predictors;
  CMatrix ** second_predictors;

  /*set random seed*/
  seed_in((long *) NULL, S_evaluator);

  random_effects = false;
  fixed_effects = false;
  second_effects = false;

  //the data  
  //the responses
  counts = new CVector * [ (int) (*number_groups) ];
  start_index = 0;
  number_obs = 0;
  for ( i = 0; i < (int) (*number_groups); i++ )
  {
    counts[i] = new CVector( (int) number_data[i] );
    for ( j = 0; j < (int) number_data[i]; j++ )
    {
      counts[i]->Val(j) = data_counts[ start_index + j ]; 
    }
    start_index += ((int) number_data[i]);
    number_obs += ((int) number_data[i]);

    //printf( "fit: counts[%d] = \n",i );
    //counts[i]->Print();

  }//end for i

  if ( ((int) (*exposures_flag)) > 0 )
  {
    exposures = new CVector * [ (int) (*number_groups) ];
    start_index = 0;
    for ( i = 0; i < (int) (*number_groups); i++ )
    {
      exposures[i] = new CVector( (int) number_data[i] );
      for ( j = 0; j < (int) number_data[i]; j++ )
      {
        exposures[i]->Val(j) = data_exposures[ start_index + j ]; 
      }
      start_index += ((int) number_data[i]);

    }//end for i
  }//end if exposures flag    


  dim = (int) (*dim_beta);
  if ( dim > 0 )
  {
    random_effects = true;
    
    random_predictors = new CMatrix * [ (int) (*number_groups) ];
    start_index = 0;
    
    for ( i = 0; i < (int) (*number_groups); i++ )
    {
      random_predictors[i] = new CMatrix ( counts[i]->Len(), dim );
      for ( k = 0; k < counts[i]->Len(); k++ )
      {
        for ( j = 0; j < dim; j++ )
        {
          random_predictors[i]->Val( k, j ) = random_data[ start_index + k * dim + j ];
        } 
      }//end for j
      start_index += dim * counts[i]->Len();

#ifdef DEBUG1
      printf( "HPMIL: fit: random[%d] = \n",i );
      random_predictors[i]->Print();
#endif

    }//end for i
  }

  dim = (int) (*dim_gamma);
  if ( dim > 0 )
  {
    fixed_effects = true;
    
    fixed_predictors = new CMatrix * [ (int) (*number_groups) ];
    start_index = 0;
    
    for ( i = 0; i < (int) (*number_groups); i++ )
    {
      fixed_predictors[i] = new CMatrix ( counts[i]->Len(), dim );
      for ( k = 0; k < counts[i]->Len(); k++ )
      {
        for ( j = 0; j < dim; j++ )
        {
          fixed_predictors[i]->Val( k, j ) = fixed_data[ start_index + k * dim + j ];
        } 
      }//end for j
      start_index += dim * counts[i]->Len();

#ifdef DEBUG1
      printf( "HPMIL: fit: fixed[%d] = \n",i );
      fixed_predictors[i]->Print();
#endif
    }//end for i
  }

  if ( !random_effects && !fixed_effects )
  {
    printf( "fitBayesianHPM: No fixed effects nor random effects provided. This model is not valid.\n" );
    char the_error[] = "fitBayesianHPM: No fixed effects nor random effects provided. This model is not valid.";
    rtErr runtime_error( the_error );
    throw runtime_error;
  }

  dim = (int) (*dim_alpha);
  if ( dim > 0 )
  {
    second_effects = true;

    second_predictors = new CMatrix * [ (int) (*number_groups) ];
    start_index = 0;

    for ( i = 0; i < (int) (*number_groups); i++ )
    {
      second_predictors[i] = new CMatrix ( ( (int) (*dim_beta) ), dim );
      for ( k = 0; k < ( (int) (*dim_beta) ); k++ )
      {
        for ( j = 0; j < dim; j++ )
        {
          second_predictors[i]->Val( k, j ) = second_data[ start_index + k * dim + j ];
        } 

      }//end for j
      start_index += dim * ( (int) (*dim_beta) );

      //printf( "fit: second[%d] = \n",i );
      //second_predictors[i]->Print();
    }//end for i
  }

  BayesianHierarchicalGlmModel bayes_HGlm;
  
#ifdef DEBUG1
  printf( "HPMIL: counts[0] = \n");
  counts[0]->Print();
#endif
  // Just sets the number of groups and number of obs in each group
  bayes_HGlm.initialize( counts, ((int) (*number_groups) ) );

  if ( random_effects )
  {
  	// Sets the random effects predictors matrix, increases the 
  	// number of parameters, and sets the random effects flag 
  	// to true
    bayes_HGlm.randomEffects( random_predictors );
  }

  if ( fixed_effects )
  {
  	// Sets the fixed effects predictors matrix, increases the 
  	// number of parameters, and sets the fixed effects flag 
  	// to true
    bayes_HGlm.fixedEffects( fixed_predictors );
  }

  if ( second_effects )
  {
    bayes_HGlm.secondStageRandomEffects( second_predictors );
  }


  for ( i = 0; i < ((int) (*number_groups) ); i++ )
  {
    if ( random_effects )
    {
      delete random_predictors[i];
    }

    if ( fixed_effects )
    {
      delete fixed_predictors[i];
    }

    if ( second_effects )
    {
      delete second_predictors[i];
    }
  }


  if ( random_effects )
  {
    delete [] random_predictors;
  }

  if ( fixed_effects )
  {
    delete [] fixed_predictors;
  }

  if ( second_effects )
  {
    delete [] second_predictors;
  }


  bool by_column = false; //indicate not to read by row

  //the beta prior
  // 0 ==> usual full model
  // 1 ==> no alpha parameter in model. A single beta0
  // 2 ==> no alpha parameter in model. beta0 for each group
  // 3 ==> no alpha parameter in model. beta is non-informative
  if ( random_effects )
  {
    if ( ( (int) (*prior_beta_type) ) == 3 )
    {
      bayes_HGlm.betaPriorNonInformative( ((int) (*dim_beta) ) );
    }
    else
    {
      CMatrix p_betaCov( betaCov, ((int) (*dim_beta) ), ((int) (*dim_beta) ), by_column );
  
      if ( ( (int) (*prior_beta_type) ) == 0 )
      {
        bayes_HGlm.betaPrior( &p_betaCov );
      }
      else if ( ( (int) (*prior_beta_type) ) == 1 )
      {
        CVector p_beta0( betamean, ((int) (*dim_beta) ) );
        bayes_HGlm.betaPrior( &p_beta0, &p_betaCov );
      }    
      else if ( ( (int) (*prior_beta_type) ) == 2 )
      {
        CMatrix p_beta0( betamean, ((int) (*dim_beta) ), ((int) (*number_groups) ), by_column );
        bayes_HGlm.betaPrior( &p_beta0, &p_betaCov );
      }    
    }
  }

  if ( fixed_effects )
  {
    // 0 ==> usual Normal distribution
    // 1 ==> non informative
    if ( ( (int) (*prior_gamma_type) ) == 0 )
    {
      CVector p_gamma0( gammamean, ((int) (*dim_gamma) ) );
      CMatrix p_gammaCov( gammaCov, ((int) (*dim_gamma) ), ((int) (*dim_gamma) ), by_column );
      bayes_HGlm.gammaPrior( &p_gamma0, &p_gammaCov );
    }
    else
    {
      bayes_HGlm.gammaPriorNonInformative( ((int) (*dim_gamma) ) );
    }
  }

  if ( random_effects )
  {
    if ( second_effects )
    {
      // 0 ==> usual Normal distribution
      // 1 ==> non informative
      if ( ( (int) (*prior_alpha_type) ) == 0 )
      {
        CVector p_alpha0( alphamean, ((int) (*dim_alpha) ) );
        CMatrix p_alphaCov( alphaCov, ((int) (*dim_alpha) ), ((int) (*dim_alpha) ), by_column );
        bayes_HGlm.alphaPrior( &p_alpha0, &p_alphaCov );
      }
      else if ( ( (int) (*prior_alpha_type) ) == 1 )
      {
        bayes_HGlm.alphaPriorNonInformative( ((int) (*dim_alpha) ) );
      }
    }
  }


  //no non-informative case
  if ( random_effects && ((int) (*prior_beta_type)) != 3 )
  {
    // 0 ==> InvChisq
    // 1 ==> non informative
    // 2 ==> uniform shrinkage
    // 3 ==> du Mouchel
    // 4 ==> InvWishart
    if ( ( (int) (*prior_tau_type) ) == 0 )
    {
      bayes_HGlm.tau2PriorInvChisq( tauDF, tauScale );
    }
    else if ( ( (int) (*prior_tau_type) ) == 1 )
    {
      bayes_HGlm.tau2PriorNonInformative( tauPower );
    }
    else if ( ( (int) (*prior_tau_type) ) == 2 )
    {
      bayes_HGlm.tau2PriorUniformShrinkage( tauScale );
    }
    else if ( ( (int) (*prior_tau_type) ) == 3 )
    {
      bayes_HGlm.tau2PriorDuMouchel( tauScale );
    }
    else if ( ( (int) (*prior_tau_type) ) == 4 )
    {
      CMatrix p_betaCov( tauScale, ((int) (*dim_beta) ), ((int) (*dim_beta) ), by_column );

#ifdef DEBUG1
      printf("HPMIL: setting invWishart. original df = %f. original cov dim is %d, cov is\n",  (*tauDF), ((int) (*dim_beta) ) );
      p_betaCov.Print(); fflush(stdout);
#endif
      bayes_HGlm.betaCovPriorInvWishart( (*tauDF), &p_betaCov );
    }
  }


  if ( random_effects )
  {
    if ( (*betaDF) > 0 && ((int) (*prior_beta_type)) != 3 )
    {
      bayes_HGlm.betaTPrior( (*betaDF) );
    }

    if ( second_effects && (*alphaDF) > 0 && ((int) (*prior_alpha_type)) != 1 )
    {
      bayes_HGlm.alphaTPrior( (*alphaDF) );
    }
  }

  if ( fixed_effects )
  {
    if ( (*gammaDF) > 0 && ((int) (*prior_gamma_type)) != 1 )
    {
      bayes_HGlm.gammaTPrior( (*gammaDF) );
    }
  }



  //get ready for sampling
  if ( (int) (*read_init_point) )
  {
    if ( random_effects )
    {
      if ( second_effects )
      {
        CVector init_alpha( alphaInit, ((int) (*dim_alpha) ) );

#ifdef DEBUG1
        printf( "HPMIL: init alpha \n" );
        init_alpha.Print();
#endif

        bayes_HGlm.samplerAlphaInitialPoint( init_alpha );

      }
      //this is only valid for prior parameters, not for initial points
      //else if ( ((int) (*prior_beta_type) ) == 1 )
      //{
      //  CVector init_beta( betaInit, ((int) (*dim_beta) ) );
      //  bayes_HGlm.samplerBetaInitialPoint( init_beta );
      //}
      else //if ( ((int) (*prior_beta_type) ) == 2 )
      {
        CMatrix init_beta( betaInit, ((int) (*dim_beta) ), ((int) (*number_groups) ), by_column );

#ifdef DEBUG1
        printf( "HPMIL: init beta \n" );
        init_beta.Print();
#endif

        bayes_HGlm.samplerBetaInitialPoint( init_beta );
      }
    
      if ( ((int) (*prior_beta_type) ) != 3 )
      {
        if ( ((int) (*prior_tau_type) ) != 4 )
        {
          bayes_HGlm.samplerTau2InitialPoint( tau2Init );

#ifdef DEBUG1
          printf( "HPMIL: init random var \n %f\n", (*tau2Init) );
#endif
        }
        else
        {
          CMatrix init_tau2( tau2Init, ((int) (*dim_beta) ), ((int) (*dim_beta) ), by_column );
#ifdef DEBUG1
          printf( "HPMIL: init random var \n" );
          init_tau2.Print();
#endif

          bayes_HGlm.samplerTau2InitialPoint( init_tau2 );
        }
      }
    }

    if ( fixed_effects )
    {
      CVector init_gamma( gammaInit, ((int) (*dim_gamma) ) );

#ifdef DEBUG1
      printf( "HPMIL: init gamma \n" );
      init_gamma.Print();
#endif

      bayes_HGlm.samplerGammaInitialPoint( init_gamma );
    }
  }//end if initial points provided
  else
  {
    bayes_HGlm.samplerDefaultInitialPoint();
  }


  //connect with the Poisson part
  BayesianPoissonIdLinkModel bayes_PoissonIL;

  if ( ((int) (*exposures_flag)) > 0 )
  {
  	// Sets the counts and exposures data.  Initializes the mu_linear and residuals matrices.
  	// Initializes log_lambda and log_lambda_previous to zero.  Increments the number of
  	// parameters in the poisson part.
    bayes_PoissonIL.initialize( counts, exposures, ((int) (*number_groups) ) );
  }
  else
  {
  	// Similar, without setting the exposures data.
    bayes_PoissonIL.initialize( counts, ((int) (*number_groups) ) );
  }  

  if ( ((int) (*model_type)) == 0 )
  {
    bayes_PoissonIL.setModelType( "Binomial" );
  }

  for ( i = 0; i < ((int) (*number_groups)); i++ )
  {
    delete counts[i];
    if ( ((int) (*exposures_flag)) > 0 )
    {
      delete exposures[i];
    }
  }  
  delete [] counts;
  if ( ((int) (*exposures_flag)) > 0 )
  {
    delete [] exposures;
  }

  //prior for Sigma in Poisson part
  // for common sigma
  // 0 ==> independent sigmas; different hyper prior parameters
  // 1 ==> independent sigmas; same hyper prior parameters
  // 2 ==> common sigma; same hyper prior parameters
  if ( ( (int) (*common_sigma) ) == 0 || ( (int) (*common_sigma) ) == 1 )
  {
    bayes_PoissonIL.sigma2CommonPrior( false );

    //for prior sigma type
    // 0 ==> InvChisq
    // 1 ==> non informative
    // 2 ==> uniform shrinkage
    // 3 ==> du Mouchel
    // 4 ==> known
    if ( ( (int) (*common_sigma) ) == 0 )
    {
      if ( ( (int) (*prior_sigma_type) ) == 0 )
      {
        bayes_PoissonIL.sigma2PriorInvChisq( sigmaDF, sigmaScale );
      }
      else if ( ( (int) (*prior_sigma_type) ) == 1 )
      {
        bayes_PoissonIL.sigma2PriorNonInformative( sigmaPower );
      }
      else if ( ( (int) (*prior_sigma_type) ) == 2 )
      {
        bayes_PoissonIL.sigma2PriorUniformShrinkage( sigmaScale );
      }
      else if ( ( (int) (*prior_sigma_type) ) == 3 )
      {
        bayes_PoissonIL.sigma2PriorDuMouchel( sigmaScale );
      }
      else if ( ( (int) (*prior_sigma_type) ) == 4 )
      {
        bayes_PoissonIL.sigma2Known( sigmaScale );
      }
    }
  }
  else
  {
    bayes_PoissonIL.sigma2CommonPrior( true );
  }

  if ( ( (int) (*common_sigma) ) != 0 )
  {
    if ( ( (int) (*prior_sigma_type) ) == 0 )
    {
      bayes_PoissonIL.sigma2PriorInvChisq( (*sigmaDF), (*sigmaScale) );
    }
    else if ( ( (int) (*prior_sigma_type) ) == 1 )
    {
      bayes_PoissonIL.sigma2PriorNonInformative( (*sigmaPower) );
    }
    else if ( ( (int) (*prior_sigma_type) ) == 2 )
    {
      bayes_PoissonIL.sigma2PriorUniformShrinkage( (*sigmaScale) );
    }
    else if ( ( (int) (*prior_sigma_type) ) == 3 )
    {
      bayes_PoissonIL.sigma2PriorDuMouchel( (*sigmaScale) );
    }
    else if ( ( (int) (*prior_sigma_type) ) == 4 )
    {
      bayes_PoissonIL.sigma2Known( (*sigmaScale) );
    }
  }


  if ( (int) (*read_init_point) )
  {
    if ( ((int) (*prior_sigma_type)) != 4 )
    {
      if ( ((int) (*common_sigma) ) != 0 )
      {
      	#ifdef DEBUG_LAMBDA
      	  printf( "fitBayesianHPMIL: Initial sigma2 value= %f\n", (*sigma2Init) ); 
      	  fflush(stdout);
      	#endif
      	// Sets the sigma2 first draw.
        bayes_PoissonIL.samplerSigma2InitialPoint( (*sigma2Init) );
      }
      else
      {
        CVector init_sigma2( sigma2Init, ((int) (*number_groups) ) );
        bayes_PoissonIL.samplerSigma2InitialPoint( init_sigma2 );
      }
    }
  }//end if initial points provided  
  else
  {
    // Sets the sigma2 first draw.
    bayes_PoissonIL.samplerDefaultInitialPoint();
  }


  //connect both parts
  bayes_HGlm.glmModel( &bayes_PoissonIL );

  bayes_HGlm.setUpdateProposalCovariance( false );


  //get ready to start Gibbs sampler
  MetropolisHastings sampler( (int) (*burnInLength), 
                              (int) (*simulationsToPerform),
                              (int) (*sampleFrequency) );

  if ( (*print_statistics) )
  {
    sampler.saveStatistics( true );
  }
  

  //start MetropolisHastings sampler
  sampler.doMetropolisHastings( &bayes_HGlm );

  simulations_kept = sampler.simulationsKept();

  if ( (*print_statistics) )
  {
    sampler.printDrawingStats( mh_drawing_stats );   
    //sampler.printDrawingStats();   
  }


  //get the output simulation samples 
  bayes_HGlm.simulationsToArray( output_simulations, simulations_kept );

  /* update random seed */
  seed_out( (long * ) NULL, S_evaluator );

}//end


}
    

